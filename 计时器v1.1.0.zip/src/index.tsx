import React, { useEffect, useState } from "react";
import {
  Extension,
  extension,
  method,
  settings,
  useExtensionContext,
  type ExtensionContext,
  type SettingsBuilder,
} from "@avg-studio/sdk";

/* ------------------------------------------------------------------ *
 * 计时器v1.1.0（timer-1.0）
 *
 * 功能：在游戏画面四个角落（左上/右上/左下/右下）任意一处挂载
 *       一个「现实游玩时间」计时器，格式为 时:分:秒:毫秒。
 *       - 在剧本编辑器的「调用扩展方法」Block（tab 面板）中选择
 *         「注册计时器」，指定角落即可添加一个计时器（从注册时刻
 *         起算现实时间）。
 *       - 默认按 P 键可暂停/继续计时器（第一次暂停、第二次继续），
 *         键位可在设置面板自由修改，修改即时生效。
 *       - 计时器浮层不拦截游戏点击。
 * ------------------------------------------------------------------ */

/* ----------------------------- 数据结构 ----------------------------- */

/** 计时器可挂载的四个角落 */
type TimerCorner = "top-left" | "top-right" | "bottom-left" | "bottom-right";

/** 数据库中的计时器记录：角落 + 起始墙钟时间戳 + 暂停状态 */
type TimerRecord = {
  id: string;
  corner: TimerCorner;
  /** 最近一次开始计时的墙钟时间戳（毫秒） */
  startedAt: number;
  /** 暂停前已累计的毫秒（暂停时冻结在此） */
  elapsedMs?: number;
  /** 是否暂停中：1 暂停 / 0 运行（兼容旧记录：缺失视为运行） */
  paused?: number | boolean;
};

/** 计时器集合的最小操作面（与 ctx.database.collection 返回类型兼容） */
interface TimersCollection {
  find(filter?: unknown): Promise<unknown[]>;
  insertOne(data: Record<string, unknown>): Promise<{ id: string }>;
  updateOne(
    filter: Record<string, unknown>,
    update: Record<string, unknown>,
  ): Promise<unknown>;
  deleteOne(filter: Record<string, unknown>): Promise<unknown>;
}

/* ----------------------------- 工具函数 ----------------------------- */

/** 获取计时器集合（持久化在项目数据集合中，随存档保存） */
function timersCollection(ctx: ExtensionContext): TimersCollection {
  return ctx.database.collection("timers") as unknown as TimersCollection;
}

/** 把经过毫秒格式化为 时:分:秒:毫秒 */
function formatElapsed(ms: number): string {
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor(ms / 60_000) % 60;
  const s = Math.floor(ms / 1_000) % 60;
  const mmm = Math.floor(ms % 1_000);
  const pad2 = (n: number): string => String(n).padStart(2, "0");
  const pad3 = (n: number): string => String(n).padStart(3, "0");
  return `${pad2(h)}:${pad2(m)}:${pad2(s)}:${pad3(mmm)}`;
}

/** 计算某计时器当前的已走毫秒（考虑暂停冻结与已累计时长） */
function elapsedOf(t: TimerRecord, now: number): number {
  const accumulated =
    typeof t.elapsedMs === "number" && t.elapsedMs > 0 ? t.elapsedMs : 0;
  if (t.paused) return accumulated;
  const started =
    typeof t.startedAt === "number" && Number.isFinite(t.startedAt)
      ? t.startedAt
      : now;
  return accumulated + Math.max(0, now - started);
}

/**
 * 设置指定角落计时器的暂停状态。
 * 返回是否真的发生了状态变化（如该角落没有计时器或状态已相同则返回 false）。
 */
async function setCornerPaused(
  ctx: ExtensionContext,
  corner: TimerCorner,
  paused: boolean,
): Promise<boolean> {
  const col = timersCollection(ctx);
  const all = ((await col.find({})) ?? []) as TimerRecord[];
  const existing = all.find((t) => t.corner === corner);
  if (!existing) return false;
  const isPaused = !!existing.paused;
  if (paused === isPaused) return false;
  if (paused) {
    const now = Date.now();
    await col.updateOne(
      { id: existing.id },
      { $set: { elapsedMs: elapsedOf(existing, now), paused: 1 } },
    );
  } else {
    await col.updateOne(
      { id: existing.id },
      { $set: { startedAt: Date.now(), paused: 0 } },
    );
  }
  return true;
}

/** 热键切换：全部计时器统一暂停/继续（第一次暂停、第二次继续） */
async function toggleAllPaused(ctx: ExtensionContext): Promise<void> {
  const col = timersCollection(ctx);
  const all = ((await col.find({})) ?? []) as TimerRecord[];
  if (all.length === 0) {
    console.log("[计时器v1.1.0] 尚未注册任何计时器，热键无操作。");
    return;
  }
  const allPaused = all.every((t) => t.paused);
  for (const t of all) {
    await setCornerPaused(ctx, t.corner, !allPaused);
  }
  console.log(
    `[计时器v1.1.0] 热键：${allPaused ? "已继续全部" : "已暂停全部"}计时器。`,
  );
}

/** 绑定暂停热键（默认 P 键），跟随设置面板修改即时解绑/重绑 */
function bindPauseShortcut(ctx: ExtensionContext): void {
  let unbind: (() => void) | null = null;
  const bind = (): void => {
    unbind?.();
    const key = ctx.settings.get<string>("pauseKey") ?? "KeyP";
    unbind = ctx.input.bindShortcut(key, () => {
      void toggleAllPaused(ctx);
    });
  };
  bind();
  ctx.settings.subscribe("pauseKey", () => bind());
}

/** 角落 → 屏幕定位样式（fixed 四角，不拦截指针） */
function cornerStyle(corner: TimerCorner): React.CSSProperties {
  const base: React.CSSProperties = {
    position: "fixed",
    margin: 12,
    padding: "6px 12px",
    background: "rgba(0, 0, 0, 0.45)",
    color: "#fff",
    fontFamily:
      "ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace",
    fontSize: 16,
    lineHeight: 1.4,
    borderRadius: 8,
    pointerEvents: "none",
    userSelect: "none",
    zIndex: 9999,
    whiteSpace: "nowrap",
  };
  switch (corner) {
    case "top-left":
      return { ...base, top: 0, left: 0 };
    case "top-right":
      return { ...base, top: 0, right: 0 };
    case "bottom-left":
      return { ...base, bottom: 0, left: 0 };
    case "bottom-right":
      return { ...base, bottom: 0, right: 0 };
  }
}

/* ----------------------------- 计时器界面 ----------------------------- */

/** 常驻计时器浮层：50ms 刷新显示、500ms 同步数据库中的计时器列表 */
function TimerOverlay() {
  const ctx = useExtensionContext();
  const [timers, setTimers] = useState<TimerRecord[]>([]);
  const [now, setNow] = useState(() => Date.now());

  // 高频刷新「当前墙钟」，驱动毫秒走动
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 50);
    return () => clearInterval(iv);
  }, []);

  // 低频同步数据库中的计时器列表（注册/移除后 500ms 内生效）
  useEffect(() => {
    let alive = true;
    const load = async (): Promise<void> => {
      try {
        const all = (await timersCollection(ctx).find({})) ?? [];
        if (alive) setTimers(all as TimerRecord[]);
      } catch {
        /* 数据库暂不可用：保持当前显示 */
      }
    };
    void load();
    const iv = setInterval(() => void load(), 500);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, [ctx]);

  if (timers.length === 0) return null;
  return (
    <>
      {timers.map((t) => (
        <div key={t.id} style={cornerStyle(t.corner)}>
          {t.paused ? "⏸ " : ""}
          {formatElapsed(Math.max(0, elapsedOf(t, now)))}
        </div>
      ))}
    </>
  );
}

/* ----------------------------- 扩展定义 ----------------------------- */

@extension({
  id: "timer-overlay",
  label: "计时器v1.1.0",
  description:
    "在游戏画面四角任意一处显示现实游玩时间计时器（时:分:秒:毫秒）。",
})
export class TimerExt extends Extension {
  static settings = settings((s: SettingsBuilder) => ({
    pauseKey: s
      .shortcut("暂停快捷键")
      .default("KeyP")
      .describe(
        "游戏中按该键暂停/继续计时器（第一次暂停、第二次继续）。支持单键（如 KeyP、F5）与组合键（如 Ctrl+KeyZ），修改即时生效。",
      ),
  }));

  /** 引擎启动期：常驻显示计时器浮层，并绑定暂停热键 */
  static onRegister(ctx: ExtensionContext): void {
    void ctx.ui.show("timer-overlay", {}, { pointerEventsPassthrough: true });
    bindPauseShortcut(ctx);
  }

  /** 剧本方法：在指定角落添加/重置一个计时器 */
  static registerTimer = method({
    title: "注册计时器",
    description:
      "在画面指定角落添加一个现实游玩时间计时器（从注册时刻起算）。若该角落已有时钟，将重置重新计时。",
    schema: {
      corner: {
        type: "enum",
        label: "屏幕角落",
        options: [
          { value: "top-left", label: "左上" },
          { value: "top-right", label: "右上" },
          { value: "bottom-left", label: "左下" },
          { value: "bottom-right", label: "右下" },
        ],
        default: "top-left",
        required: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: { corner: TimerCorner },
    ): Promise<void> {
      const col = timersCollection(ctx);
      const all = ((await col.find({})) ?? []) as TimerRecord[];
      const existing = all.find((t) => t.corner === params.corner);
      const now = Date.now();
      if (existing) {
        await col.updateOne(
          { id: existing.id },
          { $set: { startedAt: now, elapsedMs: 0, paused: 0 } },
        );
        console.log(
          `[计时器v1.1.0] 已重置「${params.corner}」计时器（从此刻重新计时）。`,
        );
      } else {
        await col.insertOne({
          corner: params.corner,
          startedAt: now,
          elapsedMs: 0,
          paused: 0,
        });
        console.log(
          `[计时器v1.1.0] 已在「${params.corner}」添加计时器。`,
        );
      }
    },
  });

  /** 剧本方法：暂停指定角落的计时器（冻结当前时长） */
  static pauseTimer = method({
    title: "暂停计时器",
    description:
      "暂停指定角落的计时器：时长冻结在当前值，不再累计。已暂停的计时器再次调用不会重复暂停。",
    schema: {
      corner: {
        type: "enum",
        label: "屏幕角落",
        options: [
          { value: "top-left", label: "左上" },
          { value: "top-right", label: "右上" },
          { value: "bottom-left", label: "左下" },
          { value: "bottom-right", label: "右下" },
        ],
        default: "top-left",
        required: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: { corner: TimerCorner },
    ): Promise<void> {
      const changed = await setCornerPaused(ctx, params.corner, true);
      if (!changed) {
        console.log(
          `[计时器v1.1.0] 「${params.corner}」没有运行中的计时器可暂停。`,
        );
        return;
      }
      console.log(`[计时器v1.1.0] 已暂停「${params.corner}」计时器。`);
    },
  });

  /** 剧本方法：继续运行指定角落的计时器（从暂停处继续累计） */
  static resumeTimer = method({
    title: "继续计时器",
    description:
      "继续运行指定角落的计时器：从暂停时的冻结时长继续累计。运行中的计时器再次调用无影响。",
    schema: {
      corner: {
        type: "enum",
        label: "屏幕角落",
        options: [
          { value: "top-left", label: "左上" },
          { value: "top-right", label: "右上" },
          { value: "bottom-left", label: "左下" },
          { value: "bottom-right", label: "右下" },
        ],
        default: "top-left",
        required: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: { corner: TimerCorner },
    ): Promise<void> {
      const changed = await setCornerPaused(ctx, params.corner, false);
      if (!changed) {
        console.log(
          `[计时器v1.1.0] 「${params.corner}」没有暂停中的计时器可继续。`,
        );
        return;
      }
      console.log(`[计时器v1.1.0] 已继续「${params.corner}」计时器。`);
    },
  });

  render() {
    return {
      component: TimerOverlay,
      props: this.data ?? {},
    };
  }
}
