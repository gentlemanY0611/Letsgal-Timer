/** 舞台立绘的稳定目标；同一角色在不同渲染层是两个独立目标。 */
export interface CharacterStageTarget {
  characterId: string;
  layer: "normal" | "overlay";
}

/** stageCharacter 参数使用字符串保存，可直接传给 CharacterAPI 的舞台位置接口。 */
export function serializeCharacterStageTarget(target: CharacterStageTarget): string {
  return `stage-character:${target.layer}:${encodeURIComponent(target.characterId)}`;
}

/** 解析精确舞台目标；旧的纯角色 ID 与非法值返回 null。 */
export function parseCharacterStageTarget(value: string): CharacterStageTarget | null {
  const match = /^stage-character:(normal|overlay):(.+)$/.exec(value);
  if (!match) return null;
  try {
    const characterId = decodeURIComponent(match[2]);
    return characterId ? { characterId, layer: match[1] as CharacterStageTarget["layer"] } : null;
  } catch {
    return null;
  }
}
