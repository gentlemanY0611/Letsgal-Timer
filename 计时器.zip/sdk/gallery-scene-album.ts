import type { GalleryLayer, GallerySceneLighting } from "./sdk-context";

/** 图集中的一项是完整场景快照，不能把图层拆成多张 CG。 */
export interface GallerySceneSnapshot extends Record<string, unknown> {
  sceneId: string;
  title: string;
  layers: GalleryLayer[];
  lighting?: GallerySceneLighting;
}

export function gallerySceneSnapshots(value: unknown): GallerySceneSnapshot[] {
  if (typeof value === "string") {
    try { value = JSON.parse(value); } catch { return []; }
  }
  if (!Array.isArray(value)) return [];
  const result: GallerySceneSnapshot[] = [];
  const seen = new Set<string>();
  for (const item of value) {
    if (!item || typeof item !== "object" || typeof item.sceneId !== "string" || !item.sceneId.trim()
      || !Array.isArray(item.layers) || !item.layers.length
      || !item.layers.every((layer: unknown) => layer && typeof layer === "object"
        && typeof (layer as GalleryLayer).assetPath === "string" && (layer as GalleryLayer).assetPath.trim())) continue;
    if (seen.has(item.sceneId)) continue;
    seen.add(item.sceneId);
    result.push({ ...item, title: typeof item.title === "string" && item.title.trim() ? item.title : item.sceneId });
  }
  return result;
}
