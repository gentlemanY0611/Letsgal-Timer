import React, { createContext, useContext } from "react";
import { createPortal } from "react-dom";

const ExtensionInspectorTargetContext = createContext<HTMLElement | null>(null);
ExtensionInspectorTargetContext.displayName = "ExtensionInspectorTarget";

export interface ExtensionInspectorProps {
  /** 要显示在 Studio 检查器面板里的 React 内容。 */
  children: React.ReactNode;
}

export interface ExtensionInspectorHostProviderProps {
  /** Studio 提供的稳定挂载点；预览之外的运行环境可以不提供。 */
  target?: HTMLElement | null;
  children: React.ReactNode;
}

/**
 * 将扩展 UI 的一部分渲染到 Studio 检查器面板。
 *
 * 内容仍属于原来的 React 树，因此可以直接读取组件 state/context，
 * 并会随着扩展 UI 的状态变化一起更新。玩家等没有检查器挂载点的
 * 运行环境会安全地忽略这部分内容。
 *
 * @example
 * ```tsx
 * const [selected, setSelected] = useState<Item | null>(null);
 * return <>
 *   <ItemList onSelect={setSelected} />
 *   <ExtensionInspector>
 *     {selected && <ItemInspector item={selected} />}
 *   </ExtensionInspector>
 * </>;
 * ```
 */
export function ExtensionInspector({ children }: ExtensionInspectorProps) {
  const target = useContext(ExtensionInspectorTargetContext);

  if (!target) return null;
  return createPortal(children, target);
}

/** @internal 由 Studio 的扩展宿主注入检查器挂载点。 */
export function ExtensionInspectorHostProvider({
  target = null,
  children,
}: ExtensionInspectorHostProviderProps) {
  return (
    <ExtensionInspectorTargetContext.Provider value={target}>
      {children}
    </ExtensionInspectorTargetContext.Provider>
  );
}
