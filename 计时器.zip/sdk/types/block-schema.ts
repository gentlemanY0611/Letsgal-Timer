/**
 * string 参数的编辑期候选值声明。
 *
 * Studio 会把「同一扩展内声明了相同 key 的所有参数」在当前项目剧本里
 * 已填过的值汇成一个候选池，渲染成可输入 + 可下拉选择的控件 —— 作者
 * 第一次在某处填过"小美"，其它指令的同类参数就能直接下拉选到，不用
 * 手敲、也不会敲错。声明处即收集处：写这个 key 的地方既是数据源也是
 * 下拉消费者。
 *
 * 运行时行为不受影响：值仍是普通字符串，扩展照常收到作者填的文本。
 */
export interface BlockFieldSuggestions {
  /** 候选池分组名（扩展内唯一即可，如 "contact"、"track"）。 */
  key: string;
  /**
   * 额外把角色库的所有角色名并入候选。适合"这个参数通常就是某个角色"
   * 的场景（手机联系人、称呼等）：项目里还没有任何历史值时，下拉里
   * 直接就有全部角色可选。
   */
  includeCharacterNames?: boolean;
}

export interface BlockFieldVisibility {
  /**
   * 仅在另一个参数等于指定字面量时显示该字段。控制参数绑定变量时，
   * Studio 会保留字段可见，避免创作者无法编辑运行时可能启用的配置。
   */
  visibleWhen?: {
    field: string;
    equals: string | number | boolean;
  };
}

/** position 与同级预设下拉框联动；用户保存的坐标会同时写进指令，不依赖预设存在。 */
export interface BlockPositionPresets {
  /** 同级 enum 参数名；微调时将其切换为 customValue。 */
  field: string;
  customValue: string;
  /** 内置预设的绝对坐标。选预设时 position 恢复 default（相对预设的中心偏移）。 */
  positions: Record<string, string>;
  /** 可选：扩展项目设置中保存 {id,name,position} 数组的完整 key。 */
  settingsKey?: string;
}

/**
 * 列表参数每一行里可以放的字段类型。
 *
 * 只收「填一个值就够」的基础类型；刻意不含列表自身（不支持列表套列表）、任意数据，
 * 以及位置、场景、片段、变量、界面、立绘这类需要联动或专门选择器的类型。
 */
export type BlockListItemField =
  | { type: "string"; label?: string; default?: string; multiline?: boolean }
  | {
      type: "number";
      label?: string;
      default?: number;
      min?: number;
      max?: number;
      step?: number;
      /** 数值输入旁显示的单位，例如 `%`、`px` 或 `秒`。 */
      unit?: string;
    }
  | { type: "boolean"; label?: string; default?: boolean }
  | {
      type: "enum";
      label?: string;
      default?: string;
      options: ReadonlyArray<{ label: string; value: string; userContent?: boolean }>;
    }
  | {
      type: "asset";
      label?: string;
      assetType?: "image" | "audio" | "video" | "any";
    }
  | { type: "character"; label?: string };

/** 列表参数一行里单个字段的值。 */
export type BlockListItemValue = string | number | boolean;

/**
 * 列表参数：一组可增删的行，每行由 `item` 里声明的字段组成。
 *
 * - 值是「行对象」数组，例如 `[{ name: "金币", count: 10 }]`；
 * - 只能填值，不能整体绑定变量；
 * - 没填时用 `default`（没写就是空列表），每次调用都拿到一份新的拷贝；剧本里写成 null 时
 *   按没填处理，并在控制台告警；
 * - 某一行缺了字段时，运行时按该字段的 default 补齐；字段没写 default 时按类型兜底：
 *   数字 0（再收进 min / max）、开关 false、下拉第一项、其余空字符串；
 * - 行数上下限（`minItems` / `maxItems`）只在 Studio 编辑和 AI 写入时检查，运行时不检查。
 *
 * ```ts
 * rewards: {
 *   type: "list",
 *   label: "奖励",
 *   item: {
 *     name: { type: "string", label: "名称" },
 *     count: { type: "number", label: "数量", default: 1, min: 1 },
 *   },
 *   minItems: 1,
 * }
 * // run 里：params.rewards 的类型是 Array<{ name: string; count: number }>
 * ```
 */
export interface BlockListField {
  type: "list";
  label?: string;
  /** 补充说明：Studio 里悬停标签可见，AI 读取扩展信息时也会看到。 */
  description?: string;
  /** 每一行的字段。键名就是行对象里的属性名。 */
  item: Readonly<Record<string, BlockListItemField>>;
  /** 没填时使用的初始行。不写就是空列表。 */
  default?: ReadonlyArray<Readonly<Record<string, BlockListItemValue>>>;
  /** 最少几行。 */
  minItems?: number;
  /** 最多几行。 */
  maxItems?: number;
  required?: boolean;
}

/**
 * 任意数据参数：一段 JSON 数据，结构由扩展自己决定，适合配合自定义检查器保存复杂配置。
 *
 * - 必须给 `default`（不能是 `null`），`run` 拿到的参数类型按它推导：
 *   - 字面量会放宽：`1` → number、`"a"` → string。给 default 写了联合字面量类型
 *     （如 `"fast" as "fast" | "slow"`）也只推导成 string，需要更精确的类型请在 `run` 里自行断言；
 *   - 不写类型的空数组推导成 `unknown[]`、空对象推导成 `Record<string, unknown>`；
 *     想要精确的元素类型，请写成 `[] as Item[]`；
 * - 只能填值，不能整体绑定变量；剧本里的顶层值不能是 `null`（运行时遇到 null 按没填处理，
 *   改用默认值并在控制台告警）；
 * - `validate` 返回 `true` 表示通过，返回 `false` 或错误提示字符串表示不通过。Studio 编辑时
 *   实时校验，不通过就不写入；AI 写剧本时同样校验（写入前就有的同样参数值只提醒）；
 *   运行时再校验一次，不通过只在控制台警告，照常把值交给方法；
 * - `validate` 的参数必须标类型，并写成箭头函数：`validate: (value: unknown) => ...`。
 *   参数不标类型、写成 `function` 表达式、写成方法简写 `validate(value) {}`（后两种哪怕标了
 *   类型也一样）都会让整个方法的参数类型推导失败。出错时的症状：`schema` 处报
 *   「... is not assignable to type 'undefined'」（不能赋给 undefined），`run` 里的参数全部变成 `never`。
 *
 * ```ts
 * shop: {
 *   type: "data",
 *   label: "商店配置",
 *   description: "{ currency: string; items: Array<{ id: string; price: number }> }",
 *   default: { currency: "gold", items: [] as Array<{ id: string; price: number }> },
 *   validate: (value: unknown) =>
 *     typeof value === "object" && value !== null && "items" in value
 *       ? true
 *       : "缺少 items 字段",
 * }
 * ```
 */
export interface BlockDataField {
  type: "data";
  label?: string;
  /** 写清数据结构：Studio 里悬停标签可见，AI 读取扩展信息时也会看到。 */
  description?: string;
  /** 必填，不能是 null：没填时使用的值，也是 `run` 参数类型的推导来源。 */
  default: NonNullable<unknown>;
  /**
   * 可选校验：返回 true 通过；返回 false 或错误提示字符串表示不通过。
   * 必须写成参数标了类型的箭头函数 `(value: unknown) => ...`，见上方说明。
   */
  validate?: (value: unknown) => boolean | string;
  required?: boolean;
}

export type BlockSchemaField = BlockFieldVisibility & (
  | {
      type: "string";
      label?: string;
      default?: string;
      multiline?: boolean;
      required?: boolean;
      /** 编辑期候选值下拉（见 BlockFieldSuggestions）。多行文本不建议声明。 */
      suggestions?: BlockFieldSuggestions;
    }
  | {
      type: "number";
      label?: string;
      default?: number;
      min?: number;
      max?: number;
      step?: number;
      /** 数值输入旁显示的单位，例如 `%`、`px` 或 `秒`。 */
      unit?: string;
      /** Slider 仍以 max 为上限，但允许输入框填写更大的自定义值。 */
      allowOverflowInput?: boolean;
      /** 修改字面量时，把同一个数值同步写入这些同级参数。 */
      mirrorFields?: string[];
      required?: boolean;
    }
  | {
      type: "boolean";
      label?: string;
      default?: boolean;
      required?: boolean;
    }
  | {
      type: "enum";
      label?: string;
      default?: string;
      options: Array<{ label: string; value: string; userContent?: boolean }>;
      required?: boolean;
    }
  | {
      /**
       * 游戏画面内的二维位置。Studio 在扩展方法检查器中渲染可点击、可拖拽
       * 的 16:9 位置选择器，值以 `(x%,y%)` 字符串传给扩展。
       */
      type: "position";
      label?: string;
      default?: string;
      required?: boolean;
      /** 位置选择器中的对象预览语义；默认只显示定位点。 */
      previewKind?: "content" | "image" | "point";
      /**
       * 可选：关联同 schema 的 enum 字段，用 PositionAnchorPicker 自带的九宫格
       * 入口编辑锚点。关联字段仍会作为普通参数传给扩展，但不重复渲染下拉框。
       */
      anchorField?: string;
      /** 关联位置预设；自定义/已保存预设下 position 为绝对坐标。 */
      presets?: BlockPositionPresets;
      /** 选点组件的参考范围说明。 */
      coordinateSpaceLabel?: string;
    }
  | {
      type: "asset";
      /** 可选：批量添加的素材按顺序保存到 `${prefix}1`、`${prefix}2` 等同级参数。
       * 主字段仍为首张素材字符串；不改变旧参数、变量求值和素材扫描协议。 */
      additionalAssetsPrefix?: string;
      label?: string;
      assetType?: "image" | "audio" | "video" | "any";
      required?: boolean;
    }
  | { type: "character"; label?: string; required?: boolean }
  | {
      /**
       * 当前预览舞台上的可见立绘，按角色 ID + 渲染层精确选择。
       * 值为 serializeCharacterStageTarget() 产生的字符串，可直接传给
       * ctx.character.getStagePlacement()/useStagePlacement()。
       * 不包含未上场、隐藏或透明度为零的立绘；保留已保存的离场目标。
       */
      type: "stageCharacter";
      label?: string;
      required?: boolean;
    }
  | {
      type: "characterPortrait";
      label?: string;
      /**
       * 可选：关联同 schema 的 character 字段。Studio 会按该字段当前选择
       * 的角色筛选立绘；未关联时列出工程内所有去重后的立绘 id。
       */
      characterField?: string;
      required?: boolean;
    }
  | { type: "scene"; label?: string; required?: boolean;
      /** 允许追加场景快照；按顺序以 JSON 字符串保存到此同级字段。 */
      additionalScenesField?: string;
    }
  | {
      type: "fragment";
      label?: string;
      required?: boolean;
      /**
       * 可选：选择片段时，把其所属章节 id 同步写入指定的辅助参数。
       * 片段值本身仍只保存稳定的 fragment id。辅助参数不必在 schema 中另行
       * 声明；省略它即可让检查器只显示片段选择器，不暴露原始章节 ID 输入框。
       */
      chapterField?: string;
    }
  | {
      type: "variable";
      label?: string;
      required?: boolean;
      /**
       * 可选：选择变量时，把面向创作者的显示名同步写入同 schema 的另一个
       * string 字段。扩展运行时既能拿稳定 key，也能拿“好感度”这类友好名称。
       */
      displayNameField?: string;
    }
  | { type: "uiExtension"; label?: string; required?: boolean }
  | BlockListField
  | BlockDataField
);

export type BlockSchema = Record<string, BlockSchemaField>;

/** 方法参数的编辑期分组。fields 引用 schema 字段名，不改变运行时参数结构。 */
export interface BlockInspectorGroup<Field extends string = string> {
  id: string;
  label: string;
  fields: readonly Field[];
  /** 折叠标题中的当前值摘要；仅引用本组字段。 */
  summaryFields?: readonly Field[];
  collapsible?: boolean;
  /** 只在 collapsible 为 true 时生效。 */
  defaultCollapsed?: boolean;
}

export interface BlockInspectorTab<Field extends string = string> {
  id: string;
  label: string;
  /** 先显示无分组字段，再显示 groups。 */
  fields?: readonly Field[];
  groups?: readonly BlockInspectorGroup<Field>[];
}

/** 整套方法参数预设，保存在当前工程的扩展设置中。 */
export interface BlockInspectorPresets<Field extends string = string> {
  /** 对应 array 设置的完整 key（界面扩展包含 uiId 前缀）。行字段为 id/name/paramsJson。 */
  settingsKey: string;
  /** 预设选择器名称，默认“参数预设”。 */
  label?: string;
  /** 保存仍包含全部参数；应用时保留当前指令的这些字段，例如目标角色。 */
  preserveFields?: readonly Field[];
}

/** 可选的检查器布局；未列出的参数仍可编辑，无声明时继续平铺。 */
export type BlockInspectorLayout<Field extends string = string> = {
  presets?: BlockInspectorPresets<Field>;
} & (
  | { tabs: readonly BlockInspectorTab<Field>[]; defaultTab?: string; groups?: never }
  | { groups: readonly BlockInspectorGroup<Field>[]; tabs?: never; defaultTab?: never }
  | { tabs?: never; groups?: never; defaultTab?: never }
);

export type BlockParams = Record<string, unknown>;
