/** 同级素材参数保持 primitive，兼容剧本、UI 按钮、变量求值和打包扫描。 */
export function additionalAssetParamNames(params: Record<string, unknown>, prefix: string): string[] {
  return Object.keys(params).filter((key) => key.startsWith(prefix)
    && /^[1-9]\d*$/.test(key.slice(prefix.length)))
    .sort((a, b) => Number(a.slice(prefix.length)) - Number(b.slice(prefix.length)));
}

export function assetParamPaths(params: Record<string, unknown>, field: string, prefix: string): string[] {
  return [...new Set([field, ...additionalAssetParamNames(params, prefix)]
    .map((key) => params[key]).filter((value): value is string => typeof value === "string")
    .map((value) => value.trim()).filter(Boolean))];
}
