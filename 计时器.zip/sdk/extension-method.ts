/**
 * 统一模块基类(Extension)的方法声明:method() 品牌工厂。
 *
 * 设计:docs/plans/2026-06-10-unified-extension-base-class-design.md §3.3
 *
 * 一个方法 = 一个静态 property(不再一类一方法):
 *
 * ```ts
 * const inventorySave = defineSave({
 *   items: { type: "list", persistence: "slot", default: [] as string[] },
 * });
 * class InventorySystem extends Extension.withSave(inventorySave) {
 *   static addItem = this.method({
 *     title: "增加物品",
 *     schema: {
 *       itemId: { type: "string", label: "物品 ID", required: true },
 *       count:  { type: "number", label: "数量", default: 1 },
 *     },
 *     async run(ctx, params) {
 *       // params: { itemId: string; count: number } —— 从 schema 推导
 *       const items = this.save.get("items");
 *       ...
 *     },
 *   });
 * }
 * ```
 *
 * 方法 id 缺省由属性名推导(addItem → "add-item"),全局引用
 * "extId/add-item" —— 与 BlockExtension.globalType 同格式,Action block
 * 的「调用方法」链路零改动。重命名属性 = 老剧本断链,发布后建议
 * 显式锁定 `id` 字段。
 */

import type { ExtensionContext } from "./sdk-context";
import type { BlockInspectorLayout, BlockSchema } from "./types/block-schema";
import type { ExtensionBase } from "./extension-base";

const METHOD_BRAND = Symbol.for("avg.extension-method");

/** 可供剧本条件消费的扩展方法返回值类型。 */
export type ExtensionMethodReturnType = "boolean" | "number" | "string";

/**
 * 方法返回值声明。只有显式声明了 returns 的方法才会出现在 If 条件候选中；
 * label 用于在条件摘要里补充业务语义，例如“是否持有”。
 */
export interface ExtensionMethodReturns<
  T extends ExtensionMethodReturnType = ExtensionMethodReturnType,
> {
  type: T;
  label?: string;
}

export type ExtensionMethodReturnValue<
  R extends ExtensionMethodReturns | undefined,
> = R extends ExtensionMethodReturns<infer T>
  ? T extends "boolean"
    ? boolean
    : T extends "number"
      ? number
      : string
  : void;

/**
 * 方法候选的启用条件。
 *
 * - 字符串简写：读取当前 Extension 子模块同名设置；
 * - 对象形态：可指定期望值，或用 scope="extension" 读取扩展级设置；
 * - setting 含 `.` 时始终视为扩展内完整设置路径，可跨子模块引用。
 *
 * 条件只控制 Studio 中“新选择方法”的候选列表。已经写入剧本的方法仍会
 * 保持注册并可执行，避免用户关闭开关后让既有项目断链。
 */
export interface ExtensionMethodEnableCondition {
  setting: string;
  equals?: unknown;
  scope?: "module" | "extension";
}

export type ExtensionMethodEnabledWhen =
  | string
  | ExtensionMethodEnableCondition;

/** 列表参数一行里单个字段的值类型。 */
type ListParamCellOf<F> = F extends { type: "number" }
  ? number
  : F extends { type: "boolean" }
    ? boolean
    : F extends { type: "enum"; options: ReadonlyArray<{ value: infer V }> }
      ? V
      : string;

/** 列表参数的一行：字段名 → 值（数字、开关、下拉选项值，其余为字符串）。SDK 内部使用，不对外导出。 */
type ListParamRowOf<I> = { -readonly [K in keyof I]: ListParamCellOf<I[K]> };

/**
 * 任意数据参数按 default 推导类型（SDK 内部使用，不对外导出）：
 * - 字面量放宽（`1` → number、`"a"` → string，联合字面量也放宽成 string），并去掉 readonly；
 * - 不写类型的空数组 `[]` → `unknown[]`，空对象 `{}` → `Record<string, unknown>`；
 * - 想要精确类型请写成 `[] as Item[]` 这类带类型的写法。
 */
type WidenDataParam<T> = T extends string
  ? string
  : T extends number
    ? number
    : T extends boolean
      ? boolean
      : T extends readonly []
        ? unknown[]
        : T extends readonly (infer U)[]
          ? WidenDataParam<U>[]
          : T extends object
            ? [keyof T] extends [never]
              ? Record<string, unknown>
              : { -readonly [K in keyof T]: WidenDataParam<T[K]> }
            : T;

/**
 * schema → params 的类型推导:作者在 run 里拿到强类型参数。
 * - number / boolean / enum 推导成对应类型；
 * - list 推导成「行对象」数组，每行字段按 item 推导；
 * - data 按 default 推导（见 WidenDataParam）；
 * - string/asset/character/scene/fragment/variable 等 id 类参数统一 string。
 */
export type ParamsOf<S extends BlockSchema | undefined> = S extends BlockSchema
  ? {
      [K in keyof S]: S[K] extends { type: "list"; item: infer I }
        ? ListParamRowOf<I>[]
        : S[K] extends { type: "data"; default: infer D }
          ? WidenDataParam<D>
          : S[K] extends { type: "number" }
            ? number
            : S[K] extends { type: "boolean" }
              ? boolean
              : S[K] extends {
                    type: "enum";
                    options: ReadonlyArray<{ value: infer V }>;
                  }
                ? V
                : string;
    }
  : Record<string, never>;

export interface ExtensionMethodDef<
  S extends BlockSchema | undefined = BlockSchema | undefined,
  R extends ExtensionMethodReturns | undefined =
    | ExtensionMethodReturns
    | undefined,
  Owner extends ExtensionBase<any, any> = ExtensionBase,
> {
  /** 方法 picker 里显示的名字。 */
  title: string;
  description?: string;
  /**
   * 可选:显式方法 id(kebab-case)。缺省 kebabize(属性名)。
   * 发布后建议显式锁定 —— 属性重命名会让引用它的剧本断链。
   */
  id?: string;
  /** 满足指定扩展设置条件时，才在 Studio 的方法候选列表中显示。 */
  enabledWhen?: ExtensionMethodEnabledWhen;
  /** false 时仅保留历史调用与参数编辑，不在 Studio 新方法候选中显示。 */
  selectable?: boolean;
  /** 参数定义 —— Studio 自动生成参数表单(每个参数带"值/变量"切换)。 */
  schema?: S;
  /** Studio 编辑期布局；参数仍以平铺 schema 的原字段名传给 run。 */
  inspectorLayout?: BlockInspectorLayout<S extends BlockSchema ? Extract<keyof S, string> : string>;
  /**
   * 可选返回值契约。声明后，Studio 会在方法列表标注返回类型，并允许 If
   * 直接把该方法的结果作为条件左值。
   */
  returns?: R;
  /**
   * 声明这个方法可以放进演出段（时间轴演出）里调用：它很快执行完，不等待
   * 玩家操作（不打开需要玩家关闭的界面、不等点击），也不改变剧情流程（不调用
   * `ctx.flow.callFragment` / `unsafe_goToFragment`，不切换自动播放或快进）。
   *
   * 只影响 Studio 的提醒：声明后，演出段里调用这个方法的指令不再显示
   * 「没有声明可在演出中使用」的黄色提醒。运行时行为不变 —— 演出不会等待
   * 方法返回，演出期间的流程调用依然会被拒绝。缺省视为未声明。
   *
   * ```ts
   * static flashBadge = this.method({
   *   title: "闪一下徽章",
   *   performanceSafe: true,
   *   run(ctx) {
   *     // 只更新自己的界面状态，立即返回
   *   },
   * });
   * ```
   */
  performanceSafe?: boolean;
  /**
   * 隐藏这个方法：创作者在 Studio 里新选方法时看不到它（剧本方法指令、Tab 菜单、
   * 条件判断、对白超链接、画廊设置、可视化界面点击动作），AI 通过 MCP 读取扩展
   * 信息时也不会列出它。
   *
   * 只影响「能不能被选到」，不影响执行：已经写进剧本的调用、手写的调用和宿主
   * 内部调用都照常运行。适合扩展内部使用的方法，或已经过时、但要兼容老剧本的
   * 方法。例外：编辑本扩展自带的可视化界面时，点击动作里仍能选到它。缺省不隐藏。
   *
   * ```ts
   * static syncCache = this.method({
   *   title: "同步缓存",
   *   hidden: true,
   *   run(ctx) {
   *     // 只给本扩展自己的界面按钮调用
   *   },
   * });
   * ```
   */
  hidden?: boolean;
  /**
   * 执行体。this = 模块实例(可用 this.save / this.context),
   * params 已是最终值 —— 创作者填的变量引用,引擎在调用前已解好。
   */
  run(
    this: Owner,
    ctx: ExtensionContext,
    params: ParamsOf<S>,
  ): ExtensionMethodReturnValue<R> | Promise<ExtensionMethodReturnValue<R>>;
  /** 可选:立即生效版本(不等动画)。 */
  runImmediately?(
    this: Owner,
    ctx: ExtensionContext,
    params: ParamsOf<S>,
  ): ExtensionMethodReturnValue<R> | Promise<ExtensionMethodReturnValue<R>>;
  /** 可选:玩家快进时的简化行为。缺省 fallback 到 run。 */
  skip?(
    this: Owner,
    ctx: ExtensionContext,
    params: ParamsOf<S>,
  ): ExtensionMethodReturnValue<R> | Promise<ExtensionMethodReturnValue<R>>;
}

export type BrandedExtensionMethod<
  S extends BlockSchema | undefined = BlockSchema | undefined,
  R extends ExtensionMethodReturns | undefined =
    | ExtensionMethodReturns
    | undefined,
> = ExtensionMethodDef<S, R> & { readonly [METHOD_BRAND]: true };

/** 把一个方法定义打上品牌,作为静态 property 挂到 Extension 子类上。 */
export function method<
  const S extends BlockSchema | undefined = undefined,
  const R extends ExtensionMethodReturns | undefined = undefined,
>(def: ExtensionMethodDef<S, R>): BrandedExtensionMethod<S, R> {
  return Object.assign(def, { [METHOD_BRAND]: true as const });
}

/**
 * 为某个 Extension 实例类型创建 method() 的绑定版本。
 *
 * 普通全局 method() 无法知道它最终会挂到哪个类；Extension 上的静态绑定版本
 * 从调用接收者（`this.method(...)` 中的 this）推导实际子类 constructor，再用
 * InstanceType 得到完整实例类型。这样 save schema、自定义 Props、子类 helper 和
 * protected context 都能在回调中保留。返回值仍擦除 Owner，宿主侧现有方法
 * 收集/执行协议无需变化。
 */
type ExtensionMethodOwnerConstructor = abstract new (
  ...args: any[]
) => ExtensionBase<any, any>;

export interface ExtensionMethodFactory {
  <
    OwnerConstructor extends ExtensionMethodOwnerConstructor,
    const S extends BlockSchema | undefined = undefined,
    const R extends ExtensionMethodReturns | undefined = undefined,
  >(
    this: OwnerConstructor,
    def: ExtensionMethodDef<S, R, InstanceType<OwnerConstructor>>,
  ): BrandedExtensionMethod<S, R>;
}

export function createExtensionMethodFactory(): ExtensionMethodFactory {
  return method as ExtensionMethodFactory;
}

export function isExtensionMethod(
  v: unknown,
): v is BrandedExtensionMethod<BlockSchema | undefined> {
  return !!v && typeof v === "object" && METHOD_BRAND in v;
}

/** camelCase / PascalCase → kebab-case,与 uiId 推导同款规则。 */
export function kebabizeMethodName(name: string): string {
  return name.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
}

export interface ListedExtensionMethod {
  /** 方法局部 id(def.id 或属性名 kebabize)。 */
  localId: string;
  /** 静态属性名(调试/报错用)。 */
  propertyName: string;
  def: BrandedExtensionMethod<
    BlockSchema | undefined,
    ExtensionMethodReturns | undefined
  >;
}

/**
 * 列出一个 Extension 子类上声明的全部方法(扫静态 own property 认品牌)。
 * 纯函数,SDK / loader / Studio hook 共用,保证三处看到同一份方法表。
 */
export function listExtensionMethods(cls: unknown): ListedExtensionMethod[] {
  if (typeof cls !== "function") return [];
  const out: ListedExtensionMethod[] = [];
  const seen = new Set<string>();
  // 只扫 own static(不上原型链):方法属于声明它的类,避免继承带来的重复登记。
  for (const [key, value] of Object.entries(cls)) {
    if (!isExtensionMethod(value)) continue;
    const localId = value.id ?? kebabizeMethodName(key);
    if (seen.has(localId)) {
      throw new Error(
        `[listExtensionMethods] 类 "${(cls as { name?: string }).name}" 中方法 id 重复: ${localId}`,
      );
    }
    seen.add(localId);
    out.push({ localId, propertyName: key, def: value });
  }
  return out;
}
